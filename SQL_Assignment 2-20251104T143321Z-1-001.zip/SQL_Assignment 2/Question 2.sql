create database course ;
use course;
create table course(
course_id int primary key auto_increment,
course_name varchar (50) unique,
duration int not null,
fee int default 50000 check (fees<=100000));
 select * from course;

insert into course ( course_name,duration, fee)
values ('python programming',6,40000),
       ('data science', 12,95000);
       
insert into course (course_name,duration,fee)
values ('web devlopment',8) ;

select*from course where duration  >6;

select*from course where fee< 50000;
	
select distinct duration from course;

select*from course order by fees  desc limit 1;
  
 select*from course where duration between 6 and 12 order by fees ;

 select duration, count(*)as total_course from course group by duration;
 
 select course_name,duration,fees from course where fees = ( select min (fees) from course);
 
 drop table if  exists course ;
















      