create database employees;

use employees ;

create table employees (
emp_id int primary key auto_increment,
emp_name varchar (50) ,
department varchar (30),
experience int ,
salary int,
joining_data date);

insert into employees ( emp_name, department,experience ,salary, joining_data)
values ('Amit','IT', 6 , 60000,'2018-07-10'),
       ('Priya','HR',3,40000,'2021-05-18'),
       ('Ravi','sales',8,75000,'2016-11-23'),
       ('Sneha','IT',2, 35000, '2023-02-18'),
       ('Karan','finance',10,90000,'2014-04-05'),
       ('Tina','sales',5,55000,'2019-09-12');
       
select*from employees
where department='IT';    

alter table employees add column bonus int ;
update employees
set bonus = salary * 10;
update employees 
set bonus = bonus * 1.20
where salary > 70000;
 select emp_name , department, salary, 
    case 
      when salary >= 80000 then 'high'
      when salary >= 50000 then 'medium'
      else 'low'
    end as level
  from employees;  
  
  select department , avg(bonus) as avg_bonus
  from employees
  group by department;
  
  SELECT department, AVG(bonus) AS avg_bonus
FROM employees
GROUP BY department
HAVING AVG(bonus) > 4000;

SELECT department, SUM(salary + bonus) AS total_salary_bonus
FROM employees
GROUP BY department;

UPDATE employees
SET salary = salary * 1.10
WHERE department = 'Finance';  

SELECT MAX(salary) AS max_salary,
       MIN(salary) AS min_salary
FROM employees;

SELECT * FROM employees
ORDER BY bonus DESC;

SELECT department, COUNT(*) AS total_employees
FROM employees
GROUP BY department
HAVING COUNT(*) > 1;